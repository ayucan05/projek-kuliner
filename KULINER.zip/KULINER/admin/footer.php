</div>
</div>
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; 2025 GIS Admin. All Rights Reserved.</span>
        </div>
    </div>
</footer>


</div>

<script src="../assets/sb-admin/vendor/jquery/jquery.min.js"></script>
<script src="../assets/sb-admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/sb-admin/js/sb-admin-2.min.js"></script>
</body>

</html>